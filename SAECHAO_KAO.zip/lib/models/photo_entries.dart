class PhotoEntries {
  List? entries;

  PhotoEntries({required this.entries});
}
